package br.upf.ads175.critiquehub.service;

import br.upf.ads175.critiquehub.entity.enums.CategoriaFavorito;
import br.upf.ads175.critiquehub.entity.enums.TipoItem;
import br.upf.ads175.critiquehub.entity.model.ItemCultural;
import br.upf.ads175.critiquehub.entity.model.Usuario;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.junit.TestProfile;
import org.junit.jupiter.api.*;

import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class FavoritosServiceIntegrationTest {

    @Inject
    FavoritosService favoritosService;

    @Inject
    EntityManager entityManager;

    private static Long usuarioId;
    private static Long itemId;

    @BeforeEach
    @Transactional
    void criarDadosTeste() {
        if (usuarioId == null) {
            // Criar usuário de teste
            Usuario usuario = new Usuario("teste@email.com", "teste", "Usuario Teste");
            entityManager.persist(usuario);
            entityManager.flush();
            usuarioId = usuario.getId();

            // Criar item cultural de teste
            ItemCultural item = new ItemCultural("Teste", TipoItem.FILME, LocalDate.now());
            item.setTitulo("Filme Teste");
            entityManager.persist(item);
            entityManager.flush();
            itemId = item.getId();
        }
    }

    @Test
    @Order(1)
    @Transactional
    void deveAdicionarItemAosFavoritos() {
        // When
        favoritosService.adicionarAosFavoritos(
            usuarioId, itemId,
            CategoriaFavorito.QUERO_ASSISTIR,
            "Parece interessante"
        );

        // Then
        var favoritos = favoritosService.listarFavoritosPorCategoria(
            usuarioId, CategoriaFavorito.QUERO_ASSISTIR
        );

        assertEquals(1, favoritos.size());
        assertEquals("Parece interessante", favoritos.get(0).getObservacoes());
    }

    @Test
    @Order(2)
    @Transactional
    void naoDevePermitirFavoritoDuplicado() {
        // When/Then
        assertThrows(IllegalStateException.class, () -> {
            favoritosService.adicionarAosFavoritos(
                usuarioId, itemId,
                CategoriaFavorito.FAVORITO_ABSOLUTO,
                "Tentativa duplicada"
            );
        });
    }

    @Test
    @Order(3)
    @Transactional
    void deveAtualizarCategoriaDoFavorito() {
        // When
        favoritosService.atualizarCategoria(
            usuarioId, itemId, CategoriaFavorito.FAVORITO_ABSOLUTO
        );

        // Then
        var favoritos = favoritosService.listarTodosFavoritos(usuarioId);
        assertEquals(1, favoritos.size());
        assertEquals(CategoriaFavorito.FAVORITO_ABSOLUTO, favoritos.get(0).getCategoria());
    }

    @Test
    @Order(4)
    @Transactional
    void deveRemoverDosFavoritos() {
        // When
        boolean removido = favoritosService.removerDosFavoritos(usuarioId, itemId);

        // Then
        assertTrue(removido);
        var favoritos = favoritosService.listarTodosFavoritos(usuarioId);
        assertEquals(0, favoritos.size());
    }
}
