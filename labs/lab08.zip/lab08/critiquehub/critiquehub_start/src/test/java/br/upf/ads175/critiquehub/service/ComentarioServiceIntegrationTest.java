package br.upf.ads175.critiquehub.service;

import br.upf.ads175.critiquehub.entity.enums.StatusConsumo;
import br.upf.ads175.critiquehub.entity.enums.TipoItem;
import br.upf.ads175.critiquehub.entity.model.Avaliacao;
import br.upf.ads175.critiquehub.entity.model.Comentario;
import br.upf.ads175.critiquehub.entity.model.ItemCultural;
import br.upf.ads175.critiquehub.entity.model.Usuario;
import io.quarkus.test.junit.QuarkusTest;
import jakarta.inject.Inject;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@QuarkusTest
class ComentarioServiceIntegrationTest {

    @Inject
    ComentarioService comentarioService;

    @Inject
    EntityManager entityManager;

    private static Long avaliacaoId;
    private static Long autorId;

    @BeforeEach
    @Transactional
    void criarDadosTeste() {
        // Criar dados de teste básicos
        Usuario autor = new Usuario("autor@teste.com", "autor", "Autor Teste");
        entityManager.persist(autor);

        ItemCultural item = new ItemCultural("Teste", TipoItem.FILME, LocalDate.now());
        item.setTitulo("Item Teste");
        entityManager.persist(item);

        Avaliacao avaliacao = new Avaliacao(autor, item, 8, StatusConsumo.FINALIZADO );
        entityManager.persist(avaliacao);

        entityManager.flush();

        autorId = autor.getId();
        avaliacaoId = avaliacao.getId();
    }

    @Test
    void deveCriarComentarioPrincipal() {
        // When
        Comentario comentario = comentarioService.criarComentario(
            avaliacaoId, autorId, "Excelente análise!"
        );

        // Then
        assertNotNull(comentario.getId());
        assertTrue(comentario.isComentarioPrincipal());
        assertEquals("Excelente análise!", comentario.getConteudo());
    }

    @Test
    void deveCriarResposta() {
        // Given - criar comentário principal primeiro
        Comentario principal = comentarioService.criarComentario(
            avaliacaoId, autorId, "Comentário principal"
        );

        // When
        Comentario resposta = comentarioService.responderComentario(
            principal.getId(), autorId, "Concordo totalmente!"
        );

        // Then
        assertNotNull(resposta.getId());
        assertTrue(resposta.isResposta());
        assertEquals(principal.getId(), resposta.getComentarioPai().getId());
    }

    @Test
    void deveCarregarComentariosComRespostas() {
        // Given
        Comentario principal = comentarioService.criarComentario(
            avaliacaoId, autorId, "Comentário com resposta"
        );
        comentarioService.responderComentario(
            principal.getId(), autorId, "Primeira resposta"
        );
        comentarioService.responderComentario(
            principal.getId(), autorId, "Segunda resposta"
        );

        // When
        List<Comentario> comentarios = comentarioService.carregarComentariosComRespostas(avaliacaoId);

        // Then
        assertFalse(comentarios.isEmpty());
        Comentario comentarioCarregado = comentarios.stream()
                .filter(c -> c.getId().equals(principal.getId()))
                .findFirst()
                .orElseThrow();

        assertEquals(2, comentarioCarregado.getNumeroRespostas());
    }
}
