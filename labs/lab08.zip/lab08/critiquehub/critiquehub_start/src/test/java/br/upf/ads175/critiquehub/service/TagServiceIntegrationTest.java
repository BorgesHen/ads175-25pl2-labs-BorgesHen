package br.upf.ads175.critiquehub.service;

import br.upf.ads175.critiquehub.entity.model.Tag;
import br.upf.ads175.critiquehub.entity.model.ItemCultural;
import br.upf.ads175.critiquehub.entity.enums.TipoItem;
import br.upf.ads175.critiquehub.exception.EntidadeNaoEncontradaException;
import br.upf.ads175.critiquehub.exception.RegraDeNegocioException;
import br.upf.ads175.critiquehub.repository.TagRepository;
import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.TestTransaction;
import jakarta.inject.Inject;
import jakarta.transaction.Transactional;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Testes de integração para o TagService.
 */
@QuarkusTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TagServiceIntegrationTest {

    @Inject
    TagService tagService;

    @Inject
    TagRepository tagRepository;

    private Tag tagTeste;
    private ItemCultural itemTeste;

    @BeforeEach
    @Transactional
    void setUp() {
        // Limpa dados de teste anteriores
        tagRepository.delete("nome LIKE 'teste%'");

        // Cria dados de teste
        tagTeste = new Tag("testeTag", "Tag para testes");
        itemTeste = new ItemCultural("Filme Teste", TipoItem.FILME, LocalDate.now());
    }

    @Test
    @Order(1)
    @TestTransaction
    void deveCriarTagComSucesso() {
        // Given
        Tag novaTag = new Tag("acao", "Filmes de ação");

        // When
        Tag tagCriada = tagService.criar(novaTag);

        // Then
        assertNotNull(tagCriada.getId());
        assertEquals("acao", tagCriada.getNome());
        assertEquals("Filmes de ação", tagCriada.getDescricao());
        assertTrue(tagCriada.getAtivo());
        assertNotNull(tagCriada.getCor());
        assertTrue(tagCriada.getCor().matches("^#[0-9A-Fa-f]{6}$"));
    }

    @Test
    @Order(2)
    @TestTransaction
    void deveCriarTagPorNomeComSucesso() {
        // When
        Tag tagCriada = tagService.criar("drama");

        // Then
        assertNotNull(tagCriada.getId());
        assertEquals("drama", tagCriada.getNome());
        assertTrue(tagCriada.getAtivo());
        assertNotNull(tagCriada.getCor());
    }

    @Test
    @Order(3)
    @TestTransaction
    void deveCriarTagComNomeEDescricaoComSucesso() {
        // When
        Tag tagCriada = tagService.criar("comedia", "Filmes engraçados");

        // Then
        assertNotNull(tagCriada.getId());
        assertEquals("comedia", tagCriada.getNome());
        assertEquals("Filmes engraçados", tagCriada.getDescricao());
        assertTrue(tagCriada.getAtivo());
    }

    @Test
    @Order(4)
    @TestTransaction
    void naoDeveCriarTagComNomeDuplicado() {
        // Given
        tagService.criar("terror");

        // When & Then
        assertThrows(RegraDeNegocioException.class, () -> {
            tagService.criar("terror");
        });
    }

    @Test
    @Order(5)
    @TestTransaction
    void naoDeveCriarTagComNomeDuplicadoCaseInsensitive() {
        // Given
        tagService.criar("suspense");

        // When & Then
        assertThrows(RegraDeNegocioException.class, () -> {
            tagService.criar("SUSPENSE");
        });
    }

    @Test
    @Order(6)
    @TestTransaction
    void deveAtualizarTagComSucesso() {
        // Given
        Tag tagCriada = tagService.criar("romance");

        // When
        Tag tagAtualizada = new Tag("romance-atualizado", "Filmes românticos");
        Tag resultado = tagService.atualizar(tagCriada.getId(), tagAtualizada);

        // Then
        assertEquals(tagCriada.getId(), resultado.getId());
        assertEquals("romance-atualizado", resultado.getNome());
        assertEquals("Filmes românticos", resultado.getDescricao());
    }

    @Test
    @Order(7)
    @TestTransaction
    void naoDeveAtualizarTagComNomeExistente() {
        // Given
        Tag tag1 = tagService.criar("fantasia");
        Tag tag2 = tagService.criar("aventura");

        // When & Then
        Tag tagUpdate = new Tag("fantasia");
        assertThrows(RegraDeNegocioException.class, () -> {
            tagService.atualizar(tag2.getId(), tagUpdate);
        });
    }

    @Test
    @Order(8)
    @TestTransaction
    void deveBuscarTagPorIdComSucesso() {
        // Given
        Tag tagCriada = tagService.criar("biografia");

        // When
        Tag tagEncontrada = tagService.buscarPorId(tagCriada.getId());

        // Then
        assertEquals(tagCriada.getId(), tagEncontrada.getId());
        assertEquals("biografia", tagEncontrada.getNome());
    }

    @Test
    @Order(9)
    @TestTransaction
    void deveLancarExcecaoAoBuscarTagInexistente() {
        // When & Then
        assertThrows(EntidadeNaoEncontradaException.class, () -> {
            tagService.buscarPorId(99999L);
        });
    }

    @Test
    @Order(10)
    @TestTransaction
    void deveBuscarTagPorNomeComSucesso() {
        // Given
        tagService.criar("documentario");

        // When
        Optional<Tag> tagEncontrada = tagService.buscarPorNome("documentario");

        // Then
        assertTrue(tagEncontrada.isPresent());
        assertEquals("documentario", tagEncontrada.get().getNome());
    }

    @Test
    @Order(11)
    @TestTransaction
    void deveRetornarVazioAoBuscarTagInexistentePorNome() {
        // When
        Optional<Tag> tagEncontrada = tagService.buscarPorNome("inexistente");

        // Then
        assertFalse(tagEncontrada.isPresent());
    }

    @Test
    @Order(12)
    @TestTransaction
    void deveBuscarOuCriarTagExistente() {
        // Given
        Tag tagOriginal = tagService.criar("musical");

        // When
        Tag tagRetornada = tagService.buscarOuCriar("musical");

        // Then
        assertEquals(tagOriginal.getId(), tagRetornada.getId());
        assertEquals("musical", tagRetornada.getNome());
    }

    @Test
    @Order(13)
    @TestTransaction
    void deveBuscarOuCriarTagNova() {
        // When
        Tag tagCriada = tagService.buscarOuCriar("western");

        // Then
        assertNotNull(tagCriada.getId());
        assertEquals("western", tagCriada.getNome());
        assertTrue(tagCriada.getAtivo());
    }

    @Test
    @Order(14)
    @TestTransaction
    void deveListarTagsAtivas() {
        // Given
        tagService.criar("acao-lista");
        tagService.criar("drama-lista");
        Tag tagInativa = tagService.criar("inativa-lista");
        tagService.inativar(tagInativa.getId());

        // When
        List<Tag> tagsAtivas = tagService.listarAtivas();

        // Then
        assertTrue(tagsAtivas.size() >= 2);
        assertTrue(tagsAtivas.stream().allMatch(Tag::getAtivo));
        assertTrue(tagsAtivas.stream().anyMatch(t -> t.getNome().equals("acao-lista")));
        assertTrue(tagsAtivas.stream().anyMatch(t -> t.getNome().equals("drama-lista")));
        assertFalse(tagsAtivas.stream().anyMatch(t -> t.getNome().equals("inativa-lista")));
    }

    @Test
    @Order(15)
    @TestTransaction
    void deveBuscarTagsPorNomeParcial() {
        // Given
        tagService.criar("teste-parcial-1");
        tagService.criar("teste-parcial-2");
        tagService.criar("outro-nome");

        // When
        List<Tag> tagsEncontradas = tagService.buscarPorNomeParcial("teste-parcial");

        // Then
        assertEquals(2, tagsEncontradas.size());
        assertTrue(tagsEncontradas.stream().allMatch(t -> t.getNome().contains("teste-parcial")));
    }

    @Test
    @Order(16)
    @TestTransaction
    void deveAtivarTagComSucesso() {
        // Given
        Tag tag = tagService.criar("ativar-teste");
        tagService.inativar(tag.getId());

        // When
        Tag tagAtivada = tagService.ativar(tag.getId());

        // Then
        assertTrue(tagAtivada.getAtivo());
    }

    @Test
    @Order(17)
    @TestTransaction
    void deveInativarTagComSucesso() {
        // Given
        Tag tag = tagService.criar("inativar-teste");

        // When
        Tag tagInativada = tagService.inativar(tag.getId());

        // Then
        assertFalse(tagInativada.getAtivo());
    }

    @Test
    @Order(18)
    @TestTransaction
    void deveRemoverTagSemAssociacoes() {
        // Given
        Tag tag = tagService.criar("remover-teste");

        // When
        assertDoesNotThrow(() -> {
            tagService.remover(tag.getId());
        });

        // Then
        assertThrows(EntidadeNaoEncontradaException.class, () -> {
            tagService.buscarPorId(tag.getId());
        });
    }

    @Test
    @Order(19)
    @TestTransaction
    void naoDeveRemoverTagComAssociacoes() {
        // Given
        Tag tag = tagService.criar("tag-com-item");
        itemTeste.adicionarTag(tag);

        // When & Then
        assertThrows(RegraDeNegocioException.class, () -> {
            tagService.remover(tag.getId());
        });
    }

    @Test
    @Order(20)
    @TestTransaction
    void deveAssociarTagAoItem() {
        // Given
        Tag tag = tagService.criar("associar-teste");

        // When
        tagService.associarAoItem(tag.getId(), itemTeste);

        // Then
        assertTrue(itemTeste.possuiTag(tag));
        assertTrue(tag.getItens().contains(itemTeste));
    }

    @Test
    @Order(21)
    @TestTransaction
    void deveRemoverTagDoItem() {
        // Given
        Tag tag = tagService.criar("remover-item-teste");
        itemTeste.adicionarTag(tag);

        // When
        tagService.removerDoItem(tag.getId(), itemTeste);

        // Then
        assertFalse(itemTeste.possuiTag(tag));
        assertFalse(tag.getItens().contains(itemTeste));
    }

    @Test
    @Order(22)
    @TestTransaction
    void deveContarTagsAtivas() {
        // Given
        long countInicial = tagService.contarAtivas();
        tagService.criar("contar-1");
        tagService.criar("contar-2");
        Tag tagInativa = tagService.criar("contar-inativa");
        tagService.inativar(tagInativa.getId());

        // When
        long countFinal = tagService.contarAtivas();

        // Then
        assertEquals(countInicial + 2, countFinal);
    }

    @Test
    @Order(23)
    @TestTransaction
    void deveContarTodasTags() {
        // Given
        long countInicial = tagService.contarTodas();
        tagService.criar("contar-todas-1");
        tagService.criar("contar-todas-2");

        // When
        long countFinal = tagService.contarTodas();

        // Then
        assertEquals(countInicial + 2, countFinal);
    }

    @Test
    @Order(24)
    @TestTransaction
    void deveListarTagsMaisUsadas() {
        // Given
        Tag tag1 = tagService.criar("mais-usada-1");
        Tag tag2 = tagService.criar("mais-usada-2");
        Tag tag3 = tagService.criar("nao-usada");

        ItemCultural item1 = new ItemCultural("Item 1", TipoItem.FILME, LocalDate.now());
        ItemCultural item2 = new ItemCultural("Item 2", TipoItem.FILME, LocalDate.now());

        item1.adicionarTag(tag1);
        item1.adicionarTag(tag2);
        item2.adicionarTag(tag1); // tag1 tem 2 usos, tag2 tem 1 uso

        // When
        List<Tag> tagsMaisUsadas = tagService.listarMaisUsadas(5);

        // Then
        assertFalse(tagsMaisUsadas.isEmpty());
        // A primeira tag deve ser a mais usada
        if (tagsMaisUsadas.size() > 1) {
            Tag primeiraMaisUsada = tagsMaisUsadas.get(0);
            assertTrue(primeiraMaisUsada.getItens().size() >= tagsMaisUsadas.get(1).getItens().size());
        }
    }

    @Test
    @Order(25)
    @TestTransaction
    void deveListarTagsNaoUtilizadas() {
        // Given
        Tag tagUsada = tagService.criar("tag-usada-teste");
        Tag tagNaoUsada = tagService.criar("tag-nao-usada-teste");

        ItemCultural item = new ItemCultural("Item Teste", TipoItem.FILME, LocalDate.now());
        item.adicionarTag(tagUsada);

        // When
        List<Tag> tagsNaoUtilizadas = tagService.listarNaoUtilizadas();

        // Then
        assertTrue(tagsNaoUtilizadas.stream().anyMatch(t -> t.getNome().equals("tag-nao-usada-teste")));
        assertFalse(tagsNaoUtilizadas.stream().anyMatch(t -> t.getNome().equals("tag-usada-teste")));
    }

    @Test
    @Order(26)
    @TestTransaction
    void deveLimparTagsNaoUtilizadas() {
        // Given
        tagService.criar("limpar-1");
        tagService.criar("limpar-2");
        Tag tagUsada = tagService.criar("limpar-usada");

        ItemCultural item = new ItemCultural("Item Teste", TipoItem.FILME, LocalDate.now());
        item.adicionarTag(tagUsada);

        long countAntes = tagService.contarTodas();

        // When
        long tagsRemovidas = tagService.limparTagsNaoUtilizadas();

        // Then
        assertTrue(tagsRemovidas >= 2);
        long countDepois = tagService.contarTodas();
        assertEquals(countAntes - tagsRemovidas, countDepois);

        // Tag usada deve ainda existir
        assertDoesNotThrow(() -> tagService.buscarPorNome("limpar-usada"));
    }

    @Test
    @Order(27)
    @TestTransaction
    void deveNormalizarNomeTagCorretamente() {
        // Given & When
        Tag tag = tagService.criar("  TESTE MAIUSCULO  ");

        // Then
        assertEquals("teste maiusculo", tag.getNome());
    }

    @Test
    @Order(28)
    @TestTransaction
    void deveGerarCorAutomaticamente() {
        // Given & When
        Tag tag = tagService.criar("cor-automatica");

        // Then
        assertNotNull(tag.getCor());
        assertTrue(tag.getCor().matches("^#[0-9A-Fa-f]{6}$"));
    }

    @Test
    @Order(29)
    @TestTransaction
    void deveValidarNomeTagObrigatorio() {
        // When & Then
        assertThrows(IllegalArgumentException.class, () -> {
            new Tag("");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Tag(null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Tag("   ");
        });
    }
}
