package com.biblioteca.service;

import com.biblioteca.entity.Autor;
import com.biblioteca.entity.Emprestimo;
import com.biblioteca.entity.Livro;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import java.time.LocalDate;
import java.util.List;

@ApplicationScoped
public class BibliotecaService {

    @PersistenceContext
    EntityManager entityManager;

    public List<Livro> listarTodosLivros() {
        return entityManager
                .createQuery("SELECT l FROM Livro l LEFT JOIN FETCH l.autor", Livro.class)
                .getResultList();
    }

    public List<Autor> listarAutores() {
        return entityManager
                .createQuery("SELECT a FROM Autor a ORDER BY a.nome", Autor.class)
                .getResultList();
    }

    public void salvarLivro(Livro livro, Long autorId) {
        Autor autor = null;
        if (autorId != null) {
            autor = entityManager.find(Autor.class, autorId);
        }
        livro.setAutor(autor);

        if (livro.getDisponivel() == null) {
            livro.setDisponivel(Boolean.TRUE);
        }

        if (livro.getId() == null) {
            entityManager.persist(livro);
        } else {
            entityManager.merge(livro);
        }
    }

    public void removerLivro(Livro livro) {
        Livro managed = entityManager.contains(livro) ? livro : entityManager.merge(livro);
        entityManager.remove(managed);
    }

    public void registrarEmprestimo(Livro livro, String nomeUsuario) {
        Livro managedLivro = entityManager.find(Livro.class, livro.getId());
        if (managedLivro == null) {
            throw new IllegalArgumentException("Livro não encontrado para empréstimo.");
        }
        if (Boolean.FALSE.equals(managedLivro.getDisponivel())) {
            throw new IllegalStateException("Livro já está indisponível para empréstimo.");
        }

        Emprestimo emprestimo = new Emprestimo();
        emprestimo.setLivro(managedLivro);
        emprestimo.setNomeUsuario(nomeUsuario);
        emprestimo.setDataEmprestimo(LocalDate.now());
        emprestimo.setDataDevolucaoPrevista(LocalDate.now().plusWeeks(2));

        managedLivro.setDisponivel(Boolean.FALSE);

        entityManager.persist(emprestimo);
        entityManager.merge(managedLivro);
    }
}
