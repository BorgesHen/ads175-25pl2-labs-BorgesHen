package com.biblioteca.controller;

import com.biblioteca.entity.Autor;
import com.biblioteca.entity.Livro;
import com.biblioteca.service.BibliotecaService;
import jakarta.annotation.PostConstruct;
import jakarta.faces.application.FacesMessage;
import jakarta.faces.context.FacesContext;
import jakarta.faces.view.ViewScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;

import java.io.IOException;
import java.io.Serializable;
import java.security.Principal;
import java.util.List;

@Named("bibliotecaBean")
@ViewScoped
public class BibliotecaBean implements Serializable {

    @Inject
    BibliotecaService bibliotecaService;

    private Livro livro = new Livro();
    private List<Livro> livros;

    private Long autorId;
    private List<Autor> autores;

    @PostConstruct
    public void init() {
        carregarAutores();
        carregarLivros();
    }

    public void carregarLivros() {
        livros = bibliotecaService.listarTodosLivros();
    }

    public void carregarAutores() {
        autores = bibliotecaService.listarAutores();
    }

    // ================== Cadastro / Edição de Livros (ADMIN) ==================

    public String novoLivro() {
        this.livro = new Livro();
        this.autorId = null;
        return "/admin/cadastro.xhtml?faces-redirect=true";
    }

    public String editarLivro(Livro livro) {
        this.livro = livro;
        if (livro.getAutor() != null) {
            this.autorId = livro.getAutor().getId();
        } else {
            this.autorId = null;
        }
        return "/admin/cadastro.xhtml?faces-redirect=true";
    }

    public void salvarLivro() {
        try {
            bibliotecaService.salvarLivro(livro, autorId);
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                            "Livro salvo com sucesso!", null));
            this.livro = new Livro();
            this.autorId = null;
            carregarLivros();
        } catch (Exception e) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Erro ao salvar livro: " + e.getMessage(), null));
        }
    }

    public void removerLivro(Livro livro) {
        try {
            bibliotecaService.removerLivro(livro);
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                            "Livro removido com sucesso!", null));
            carregarLivros();
        } catch (Exception e) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Erro ao remover livro: " + e.getMessage(), null));
        }
    }

    // ================== Empréstimo de Livros (USER) ==================

    public void emprestar(Livro livro) {
        try {
            Principal principal = FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .getUserPrincipal();
            if (principal == null) {
                FacesContext.getCurrentInstance()
                        .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                                "Usuário não autenticado.", null));
                return;
            }
            String nomeUsuario = principal.getName();
            bibliotecaService.registrarEmprestimo(livro, nomeUsuario);
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO,
                            "Empréstimo realizado com sucesso!", null));
            carregarLivros();
        } catch (Exception e) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Erro ao emprestar livro: " + e.getMessage(), null));
        }
    }

    // ================== Sessão / Segurança ==================

    public void logout() {
        try {
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .invalidateSession();
            FacesContext.getCurrentInstance()
                    .getExternalContext()
                    .redirect("login.xhtml");
        } catch (IOException e) {
            FacesContext.getCurrentInstance()
                    .addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR,
                            "Erro ao fazer logout: " + e.getMessage(), null));
        }
    }

    public String getUsuarioLogado() {
        Principal principal = FacesContext.getCurrentInstance()
                .getExternalContext()
                .getUserPrincipal();
        return principal != null ? principal.getName() : "";
    }

    // ================== Getters e Setters ==================

    public Livro getLivro() {
        return livro;
    }

    public void setLivro(Livro livro) {
        this.livro = livro;
    }

    public List<Livro> getLivros() {
        return livros;
    }

    public Long getAutorId() {
        return autorId;
    }

    public void setAutorId(Long autorId) {
        this.autorId = autorId;
    }

    public List<Autor> getAutores() {
        return autores;
    }

    public void setAutores(List<Autor> autores) {
        this.autores = autores;
    }
}
